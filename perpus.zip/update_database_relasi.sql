-- Update Database: Tambah relasi users dengan anggota
-- Jalankan script ini untuk memperbaiki relasi data

-- 1. Tambah kolom id_user di tabel anggota
ALTER TABLE anggota 
ADD COLUMN id_user INT NULL AFTER id_anggota,
ADD INDEX idx_id_user (id_user);

-- 2. Update data anggota yang sudah ada untuk menghubungkan dengan users berdasarkan username
-- (Jika username di users sama dengan nama di anggota)
UPDATE anggota a
INNER JOIN users u ON u.username = a.nama
SET a.id_user = u.id_user
WHERE a.id_user IS NULL;

-- 3. Set id_user untuk anggota yang belum terhubung (jika ada)
-- Update manual jika diperlukan
