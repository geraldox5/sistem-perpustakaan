-- Database Perpustakaan
-- Tabel users
CREATE TABLE users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff', 'member') NOT NULL DEFAULT 'member',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel anggota
CREATE TABLE anggota (
    id_anggota INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    alamat TEXT NOT NULL,
    no_hp VARCHAR(15) NOT NULL,
    nim VARCHAR(30) DEFAULT NULL,
    password VARCHAR(255) DEFAULT NULL,
    kelas VARCHAR(50) DEFAULT NULL,
    program_studi VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE buku (
    id_buku INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    penulis VARCHAR(100) NOT NULL,
    tahun INT NOT NULL,
    stok INT NOT NULL DEFAULT 0,
    program_studi VARCHAR(100) DEFAULT NULL,
    jenis_buku VARCHAR(100) DEFAULT NULL,
    rak VARCHAR(50) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pengaturan sistem (konfigurasi umum)
CREATE TABLE IF NOT EXISTS pengaturan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_setting VARCHAR(100) UNIQUE NOT NULL,
    nilai VARCHAR(255) NOT NULL,
    keterangan TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel peminjaman
CREATE TABLE peminjaman (
    id_pinjam INT AUTO_INCREMENT PRIMARY KEY,
    id_anggota INT NOT NULL,
    id_buku INT NOT NULL,
    tgl_pinjam DATE NOT NULL,
    tgl_jatuh_tempo DATE DEFAULT NULL,
    durasi_pinjam INT DEFAULT 7 COMMENT 'Durasi dalam hari',
    perpanjangan INT DEFAULT 0 COMMENT 'Jumlah perpanjangan',
    tgl_perpanjangan DATE NULL,
    status ENUM('dipinjam', 'dikembalikan') DEFAULT 'dipinjam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_anggota) REFERENCES anggota(id_anggota) ON DELETE CASCADE,
    FOREIGN KEY (id_buku) REFERENCES buku(id_buku) ON DELETE CASCADE
);

-- Tabel pengembalian
CREATE TABLE pengembalian (
    id_kembali INT AUTO_INCREMENT PRIMARY KEY,
    id_pinjam INT NOT NULL,
    tgl_kembali DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pinjam) REFERENCES peminjaman(id_pinjam) ON DELETE CASCADE
);

-- Tabel denda
CREATE TABLE IF NOT EXISTS denda (
    id_denda INT AUTO_INCREMENT PRIMARY KEY,
    id_pinjam INT NOT NULL,
    jumlah_denda DECIMAL(10,2) DEFAULT 0,
    status ENUM('belum_lunas', 'lunas') DEFAULT 'belum_lunas',
    tgl_bayar DATE NULL,
    keterangan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pinjam) REFERENCES peminjaman(id_pinjam) ON DELETE CASCADE
);

-- Stored Procedure untuk tambah peminjaman
DELIMITER //
CREATE PROCEDURE tambah_peminjaman(
    IN p_id_anggota INT,
    IN p_id_buku INT,
    IN p_tgl_pinjam DATE
)
BEGIN
    DECLARE v_stok INT;
    DECLARE v_jumlah_pinjam INT;
    DECLARE v_duplikat INT;
    DECLARE v_max_peminjaman INT DEFAULT 3;
    DECLARE v_durasi_default INT DEFAULT 7;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    -- Ambil konfigurasi dari tabel pengaturan jika ada
    SELECT CAST(nilai AS SIGNED) INTO v_max_peminjaman
    FROM pengaturan WHERE nama_setting = 'maksimal_peminjaman'
    LIMIT 1;
    
    IF v_max_peminjaman IS NULL OR v_max_peminjaman <= 0 THEN
        SET v_max_peminjaman = 3;
    END IF;
    
    SELECT CAST(nilai AS SIGNED) INTO v_durasi_default
    FROM pengaturan WHERE nama_setting = 'durasi_peminjaman'
    LIMIT 1;
    
    IF v_durasi_default IS NULL OR v_durasi_default <= 0 THEN
        SET v_durasi_default = 7;
    END IF;
    
    START TRANSACTION;
    
    -- Cek stok buku
    SELECT stok INTO v_stok FROM buku WHERE id_buku = p_id_buku FOR UPDATE;
    
    IF v_stok <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stok buku tidak mencukupi';
    END IF;
    
    -- Cek jumlah peminjaman aktif anggota
    SELECT COUNT(*) INTO v_jumlah_pinjam
    FROM peminjaman
    WHERE id_anggota = p_id_anggota AND status = 'dipinjam';
    
    IF v_jumlah_pinjam >= v_max_peminjaman THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Maksimal peminjaman aktif telah tercapai';
    END IF;
    
    -- Cek apakah anggota sudah meminjam buku yang sama dan belum dikembalikan
    SELECT COUNT(*) INTO v_duplikat
    FROM peminjaman
    WHERE id_anggota = p_id_anggota
      AND id_buku = p_id_buku
      AND status = 'dipinjam';
    
    IF v_duplikat > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Anda masih meminjam buku yang sama dan belum dikembalikan';
    END IF;
    
    -- Tambah peminjaman dengan tanggal jatuh tempo
    INSERT INTO peminjaman (id_anggota, id_buku, tgl_pinjam, tgl_jatuh_tempo, durasi_pinjam, status) 
    VALUES (
        p_id_anggota, 
        p_id_buku, 
        p_tgl_pinjam, 
        DATE_ADD(p_tgl_pinjam, INTERVAL v_durasi_default DAY),
        v_durasi_default,
        'dipinjam'
    );
    
    -- Catatan: stok buku akan dikurangi oleh trigger trigger_kurangi_stok
    
    COMMIT;
END //
DELIMITER ;

-- Stored Procedure untuk tambah pengembalian
DELIMITER //
CREATE PROCEDURE tambah_pengembalian(
    IN p_id_pinjam INT,
    IN p_tgl_kembali DATE
)
BEGIN
    DECLARE v_id_buku INT;
    DECLARE v_tgl_jatuh_tempo DATE;
    DECLARE v_denda_per_hari DECIMAL(10,2);
    DECLARE v_hari_telat INT;
    DECLARE v_jumlah_denda DECIMAL(10,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Ambil id_buku dan tanggal jatuh tempo dari peminjaman
    SELECT id_buku, tgl_jatuh_tempo INTO v_id_buku, v_tgl_jatuh_tempo 
    FROM peminjaman 
    WHERE id_pinjam = p_id_pinjam
    FOR UPDATE;
    
    -- Tambah pengembalian
    INSERT INTO pengembalian (id_pinjam, tgl_kembali) 
    VALUES (p_id_pinjam, p_tgl_kembali);
    
    -- Update status peminjaman
    UPDATE peminjaman 
    SET status = 'dikembalikan'
    WHERE id_pinjam = p_id_pinjam;
    
    -- Catatan: stok buku akan ditambah oleh trigger trigger_tambah_stok
    
    -- Hitung denda jika terlambat
    SET v_hari_telat = 0;
    IF v_tgl_jatuh_tempo IS NOT NULL AND p_tgl_kembali > v_tgl_jatuh_tempo THEN
        SET v_hari_telat = DATEDIFF(p_tgl_kembali, v_tgl_jatuh_tempo);
    END IF;
    
    IF v_hari_telat > 0 THEN
        -- Ambil nilai denda per hari dari pengaturan, default 2000 jika tidak ada
        SELECT CAST(nilai AS DECIMAL(10,2)) INTO v_denda_per_hari
        FROM pengaturan
        WHERE nama_setting = 'denda_per_hari'
        LIMIT 1;
        
        IF v_denda_per_hari IS NULL OR v_denda_per_hari <= 0 THEN
            SET v_denda_per_hari = 2000;
        END IF;
        
        SET v_jumlah_denda = v_denda_per_hari * v_hari_telat;
        
        INSERT INTO denda (id_pinjam, jumlah_denda, status, keterangan)
        VALUES (
            p_id_pinjam,
            v_jumlah_denda,
            'belum_lunas',
            CONCAT('Terlambat ', v_hari_telat, ' hari')
        );
    END IF;
    
    COMMIT;
END //
DELIMITER ;

-- Trigger untuk mengurangi stok saat peminjaman
DELIMITER //
CREATE TRIGGER trigger_kurangi_stok
AFTER INSERT ON peminjaman
FOR EACH ROW
BEGIN
    UPDATE buku SET stok = stok - 1 WHERE id_buku = NEW.id_buku;
END //
DELIMITER ;

-- Trigger untuk menambah stok saat pengembalian
DELIMITER //
CREATE TRIGGER trigger_tambah_stok
AFTER INSERT ON pengembalian
FOR EACH ROW
BEGIN
    DECLARE v_id_buku INT;
    SELECT id_buku INTO v_id_buku FROM peminjaman WHERE id_pinjam = NEW.id_pinjam;
    UPDATE buku SET stok = stok + 1 WHERE id_buku = v_id_buku;
END //
DELIMITER ;

-- ========================================
-- INSERT DATA DUMMY LENGKAP
-- ========================================

-- Users (2 admin, 2 staff, 2 member)

-- Anggota (20 data dummy)
INSERT INTO anggota (nama, alamat, no_hp) VALUES
('Ahmad Rizki', 'Jl. Merdeka No. 123, Jakarta Pusat', '081234567890'),
('Siti Nurhaliza', 'Jl. Sudirman No. 45, Jakarta Selatan', '081234567891'),
('Budi Santoso', 'Jl. Thamrin No. 67, Jakarta Pusat', '081234567892'),
('Dewi Sartika', 'Jl. Gatot Subroto No. 89, Jakarta Selatan', '081234567893'),
('Rudi Hermawan', 'Jl. Asia Afrika No. 12, Bandung', '081234567894'),
('Nina Kartika', 'Jl. Ahmad Yani No. 34, Bandung', '081234567895'),
('Agus Setiawan', 'Jl. Diponegoro No. 56, Semarang', '081234567896'),
('Maya Indah', 'Jl. Hayam Wuruk No. 78, Yogyakarta', '081234567897'),
('Doni Prasetyo', 'Jl. Veteran No. 90, Surabaya', '081234567898'),
('Rina Safitri', 'Jl. Pahlawan No. 11, Malang', '081234567899'),
('Joko Widodo', 'Jl. Malioboro No. 22, Yogyakarta', '081234567800'),
('Sri Mulyani', 'Jl. Sudirman No. 33, Jakarta Pusat', '081234567801'),
('Bambang Brodjonegoro', 'Jl. Thamrin No. 44, Jakarta Pusat', '081234567802'),
('Erick Thohir', 'Jl. Gatot Subroto No. 55, Jakarta Selatan', '081234567803'),
('Luhut Binsar', 'Jl. Asia Afrika No. 66, Bandung', '081234567804'),
('Prabowo Subianto', 'Jl. Ahmad Yani No. 77, Bandung', '081234567805'),
('Ganjar Pranowo', 'Jl. Diponegoro No. 88, Semarang', '081234567806'),
('Anies Baswedan', 'Jl. Hayam Wuruk No. 99, Jakarta', '081234567807'),
('Sandiaga Uno', 'Jl. Veteran No. 100, Jakarta', '081234567808'),
('Ridwan Kamil', 'Jl. Pahlawan No. 111, Bandung', '081234567809');

-- Update data dummy anggota agar nim dan password terisi
UPDATE anggota SET nim = CONCAT('NIM', LPAD(id_anggota, 4, '0'));
UPDATE anggota SET password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'; -- password: password

-- Buku (25 data dummy dengan berbagai kategori)
INSERT INTO buku (judul, penulis, tahun, stok, program_studi, jenis_buku, rak) VALUES
-- Novel Indonesia
('Laskar Pelangi', 'Andrea Hirata', 2005, 8, 'Sastra', 'Fiksi', 'Rak A'),
('Bumi Manusia', 'Pramoedya Ananta Toer', 1980, 5, 'Sastra', 'Fiksi', 'Rak A'),
('Negeri 5 Menara', 'Ahmad Fuadi', 2009, 6, 'Sastra', 'Fiksi', 'Rak A'),
('Ayat-Ayat Cinta', 'Habiburrahman El Shirazy', 2004, 10, 'Sastra', 'Fiksi', 'Rak A'),
('Perahu Kertas', 'Dee Lestari', 2009, 7, 'Sastra', 'Fiksi', 'Rak A'),
('Sang Pemimpi', 'Andrea Hirata', 2006, 4, 'Sastra', 'Fiksi', 'Rak A'),
('Ronggeng Dukuh Paruk', 'Ahmad Tohari', 1982, 3, 'Sastra', 'Fiksi', 'Rak A'),
('Jalan Raya Pos, Jalan Daendels', 'Pramoedya Ananta Toer', 1995, 2, 'Sastra', 'Fiksi', 'Rak A'),
('Cantik Itu Luka', 'Eka Kurniawan', 2002, 5, 'Sastra', 'Fiksi', 'Rak A'),
('Pulang', 'Tere Liye', 2015, 8, 'Sastra', 'Fiksi', 'Rak A'),
('Hujan', 'Tere Liye', 2016, 6, 'Sastra', 'Fiksi', 'Rak A'),
('Matahari', 'Tere Liye', 2016, 4, 'Sastra', 'Fiksi', 'Rak A'),
('Bumi', 'Tere Liye', 2014, 7, 'Sastra', 'Fiksi', 'Rak A'),
('Bulan', 'Tere Liye', 2015, 5, 'Sastra', 'Fiksi', 'Rak A'),
('Bintang', 'Tere Liye', 2017, 6, 'Sastra', 'Fiksi', 'Rak A'),
-- Novel Internasional
('The Great Gatsby', 'F. Scott Fitzgerald', 1925, 3, 'Sastra', 'Fiksi', 'Rak B'),
('To Kill a Mockingbird', 'Harper Lee', 1960, 4, 'Sastra', 'Fiksi', 'Rak B'),
('1984', 'George Orwell', 1949, 5, 'Sastra', 'Fiksi', 'Rak B'),
('Pride and Prejudice', 'Jane Austen', 1813, 3, 'Sastra', 'Fiksi', 'Rak B'),
('The Catcher in the Rye', 'J.D. Salinger', 1951, 2, 'Sastra', 'Fiksi', 'Rak B'),
-- Buku Teknologi
('Clean Code', 'Robert C. Martin', 2008, 4, 'Teknik Informatika', 'Buku Teks', 'Rak C'),
('Design Patterns', 'Erich Gamma', 1994, 3, 'Teknik Informatika', 'Buku Teks', 'Rak C'),
('The Pragmatic Programmer', 'Andrew Hunt', 1999, 5, 'Teknik Informatika', 'Buku Teks', 'Rak C'),
('Refactoring', 'Martin Fowler', 1999, 3, 'Teknik Informatika', 'Buku Teks', 'Rak C'),
('Head First Design Patterns', 'Eric Freeman', 2004, 4, 'Teknik Informatika', 'Buku Teks', 'Rak C'),
('JavaScript: The Good Parts', 'Douglas Crockford', 2008, 6, 'Teknik Informatika', 'Buku Teks', 'Rak C');

-- Peminjaman (30 data dummy - beberapa sudah dikembalikan, beberapa masih dipinjam)
INSERT INTO peminjaman (id_anggota, id_buku, tgl_pinjam, status) VALUES
-- Peminjaman yang sudah dikembalikan (untuk data historis)
(1, 1, '2025-06-01', 'dikembalikan'),
(2, 3, '2025-06-02', 'dikembalikan'),
(3, 5, '2025-06-03', 'dikembalikan'),
(4, 2, '2025-06-04', 'dikembalikan'),
(5, 7, '2025-06-05', 'dikembalikan'),
(6, 4, '2025-06-06', 'dikembalikan'),
(7, 6, '2025-06-07', 'dikembalikan'),
(8, 8, '2025-06-08', 'dikembalikan'),
(9, 10, '2025-06-09', 'dikembalikan'),
(10, 12, '2025-06-10', 'dikembalikan'),
(11, 15, '2025-06-11', 'dikembalikan'),
(12, 18, '2025-06-12', 'dikembalikan'),
(13, 20, '2025-06-13', 'dikembalikan'),
(14, 22, '2025-06-14', 'dikembalikan'),
(15, 24, '2025-06-15', 'dikembalikan'),

-- Peminjaman yang masih aktif (belum dikembalikan)
(1, 9, '2025-06-16', 'dipinjam'),
(2, 11, '2025-06-17', 'dipinjam'),
(3, 13, '2025-06-18', 'dipinjam'),
(4, 16, '2025-06-19', 'dipinjam'),
(5, 19, '2025-06-20', 'dipinjam'),
(6, 21, '2025-06-21', 'dipinjam'),
(7, 23, '2025-06-22', 'dipinjam'),
(8, 25, '2025-06-23', 'dipinjam'),
(9, 1, '2025-06-24', 'dipinjam'),
(10, 3, '2025-06-25', 'dipinjam'),
(11, 5, '2025-06-26', 'dipinjam'),
(12, 7, '2025-06-27', 'dipinjam'),
(13, 10, '2025-06-28', 'dipinjam'),
(14, 12, '2025-06-29', 'dipinjam'),
(15, 15, '2025-06-30', 'dipinjam');

-- Pengembalian (15 data dummy untuk peminjaman yang sudah dikembalikan)
INSERT INTO pengembalian (id_pinjam, tgl_kembali) VALUES
(1, '2025-06-08'),  -- Laskar Pelangi dipinjam 7 hari
(2, '2025-06-09'),  -- Negeri 5 Menara dipinjam 7 hari
(3, '2025-06-10'),  -- Perahu Kertas dipinjam 7 hari
(4, '2025-06-11'),  -- Bumi Manusia dipinjam 7 hari
(5, '2025-06-12'),  -- Ronggeng Dukuh Paruk dipinjam 7 hari
(6, '2025-06-13'),  -- Ayat-Ayat Cinta dipinjam 7 hari
(7, '2025-06-14'),  -- Sang Pemimpi dipinjam 7 hari
(8, '2025-06-15'),  -- Jalan Raya Pos dipinjam 7 hari
(9, '2025-06-16'),  -- Pulang dipinjam 7 hari
(10, '2025-06-17'), -- Hujan dipinjam 7 hari
(11, '2025-06-18'), -- Bintang dipinjam 7 hari
(12, '2025-06-19'), -- The Great Gatsby dipinjam 7 hari
(13, '2025-06-20'), -- Clean Code dipinjam 7 hari
(14, '2025-06-21'), -- The Pragmatic Programmer dipinjam 7 hari
(15, '2025-06-22'); -- Head First Design Patterns dipinjam 7 hari 