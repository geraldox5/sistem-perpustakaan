# Skema Role Baru - Sistem Perpustakaan

## 📋 3 Role yang Akan Diterapkan

### 1. **Admin** (Super Administrator)
**Akses Penuh** - Mengelola seluruh sistem

**Fitur:**
- ✅ Kelola Anggota (CRUD)
- ✅ Kelola Buku (CRUD)
- ✅ Kelola Peminjaman (CRUD)
- ✅ Kelola Pengembalian (CRUD)
- ✅ Lihat Laporan (semua laporan)
- ✅ Pengaturan Sistem (konfigurasi)
- ✅ Kelola Staff Perpustakaan

**Halaman:**
- `admin/index.php` - Dashboard
- `admin/anggota.php` - Kelola Anggota
- `admin/buku.php` - Kelola Buku
- `admin/peminjaman.php` - Kelola Peminjaman
- `admin/pengembalian.php` - Kelola Pengembalian
- `admin/laporan.php` - Laporan
- `admin/staff.php` - Kelola Staff (baru)

---

### 2. **Staff Perpus** (Petugas Perpustakaan)
**Akses Operasional** - Menangani peminjaman dan pengembalian

**Fitur:**
- ❌ Kelola Anggota (TIDAK BISA)
- ✅ Kelola Buku (CRUD) - Bisa tambah/edit/hapus buku
- ✅ Kelola Peminjaman (CRUD) - Bisa approve/reject/tambah peminjaman
- ✅ Kelola Pengembalian (CRUD) - Bisa proses pengembalian
- ✅ Lihat Laporan (semua laporan)
- ❌ Pengaturan Sistem (TIDAK BISA)
- ❌ Kelola Staff (TIDAK BISA)

**Halaman:**
- `staff/index.php` - Dashboard (baru)
- `staff/buku.php` - Kelola Buku
- `staff/peminjaman.php` - Kelola Peminjaman
- `staff/pengembalian.php` - Kelola Pengembalian
- `staff/laporan.php` - Laporan

---

### 3. **Member** (Anggota/User)
**Akses Terbatas** - Hanya untuk anggota perpustakaan

**Fitur:**
- ✅ Lihat Daftar Buku
- ✅ Request Peminjaman Buku
- ✅ Lihat Riwayat Peminjaman Sendiri
- ✅ Lihat Status Peminjaman Aktif
- ✅ Ubah Profil Sendiri
- ❌ Kelola Buku (TIDAK BISA)
- ❌ Kelola Peminjaman (TIDAK BISA)
- ❌ Lihat Laporan (TIDAK BISA)

**Halaman:**
- `user/index.php` - Dashboard
- `user/daftar_buku.php` - Daftar Buku
- `user/pinjam_buku.php` - Request Pinjam Buku
- `user/riwayat.php` - Riwayat Peminjaman
- `user/ubah_profil.php` - Ubah Profil

---

## 🔄 Perubahan yang Diperlukan

### 1. Database
- Update tabel `users`: `role ENUM('admin', 'staff', 'member')`
- Default role: `'member'`

### 2. File yang Perlu Diupdate

#### Login & Register
- `login.php` - Redirect berdasarkan role (admin → admin/, staff → staff/, member → user/)
- `register.php` - Hanya bisa register sebagai 'member' (admin/staff dibuat manual)

#### Admin (Tetap)
- `admin/index.php` - Check role 'admin'
- `admin/anggota.php` - Check role 'admin'
- `admin/buku.php` - Check role 'admin'
- `admin/peminjaman.php` - Check role 'admin'
- `admin/pengembalian.php` - Check role 'admin'
- `admin/laporan.php` - Check role 'admin'
- `admin/staff.php` - Baru, hanya admin

#### Staff (Baru - Copy dari Admin)
- `staff/index.php` - Dashboard staff
- `staff/buku.php` - Kelola buku
- `staff/peminjaman.php` - Kelola peminjaman
- `staff/pengembalian.php` - Kelola pengembalian
- `staff/laporan.php` - Lihat laporan

#### User/Member (Tetap)
- `user/index.php` - Check role 'member'
- `user/daftar_buku.php` - Check role 'member'
- `user/pinjam_buku.php` - Check role 'member'
- `user/riwayat.php` - Check role 'member'
- `user/ubah_profil.php` - Check role 'member'

---

## 📝 Struktur Folder Baru

```
perpus/
├── admin/          (Role: admin)
│   ├── index.php
│   ├── anggota.php
│   ├── buku.php
│   ├── peminjaman.php
│   ├── pengembalian.php
│   ├── laporan.php
│   └── staff.php (baru)
│
├── staff/          (Role: staff) - BARU
│   ├── index.php
│   ├── buku.php
│   ├── peminjaman.php
│   ├── pengembalian.php
│   └── laporan.php
│
└── user/           (Role: member)
    ├── index.php
    ├── daftar_buku.php
    ├── pinjam_buku.php
    ├── riwayat.php
    └── ubah_profil.php
```

---

## ✅ Keuntungan Skema Baru

1. **Pemisahan Tugas Jelas**
   - Admin: Manajemen sistem penuh
   - Staff: Operasional harian
   - Member: Self-service

2. **Keamanan Lebih Baik**
   - Staff tidak bisa hapus/edit anggota
   - Member tidak bisa akses data orang lain

3. **Fleksibilitas**
   - Mudah tambah fitur khusus per role
   - Bisa expand ke role lain nanti
