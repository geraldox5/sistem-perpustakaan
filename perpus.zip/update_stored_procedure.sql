-- Update Stored Procedure untuk Peminjaman dan Pengembalian
-- Jalankan script ini untuk update stored procedure

-- 1. Drop stored procedure lama
DROP PROCEDURE IF EXISTS tambah_peminjaman;
DROP PROCEDURE IF EXISTS tambah_pengembalian;

-- 2. Stored Procedure untuk tambah peminjaman (dengan parameter jatuh tempo)
DELIMITER //
CREATE PROCEDURE tambah_peminjaman(
    IN p_id_anggota INT,
    IN p_id_buku INT,
    IN p_tgl_pinjam DATE,
    IN p_tgl_jatuh_tempo DATE,
    IN p_durasi_pinjam INT
)
BEGIN
    DECLARE v_stok INT;
    DECLARE v_jumlah_pinjam INT;
    DECLARE v_duplikat INT;
    DECLARE v_max_peminjaman INT DEFAULT 3;
    DECLARE v_durasi_default INT DEFAULT 7;
    DECLARE v_tgl_jatuh_tempo_calc DATE;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    -- Ambil konfigurasi dari tabel pengaturan jika ada
    SELECT CAST(nilai AS SIGNED) INTO v_max_peminjaman
    FROM pengaturan WHERE nama_setting = 'maksimal_peminjaman'
    LIMIT 1;
    
    IF v_max_peminjaman IS NULL OR v_max_peminjaman <= 0 THEN
        SET v_max_peminjaman = 3;
    END IF;
    
    -- Jika durasi tidak diberikan, ambil dari pengaturan
    IF p_durasi_pinjam IS NULL OR p_durasi_pinjam <= 0 THEN
        SELECT CAST(nilai AS SIGNED) INTO v_durasi_default
        FROM pengaturan WHERE nama_setting = 'durasi_peminjaman'
        LIMIT 1;
        
        IF v_durasi_default IS NULL OR v_durasi_default <= 0 THEN
            SET v_durasi_default = 7;
        END IF;
        SET p_durasi_pinjam = v_durasi_default;
    END IF;
    
    -- Hitung tanggal jatuh tempo jika tidak diberikan
    IF p_tgl_jatuh_tempo IS NULL OR p_tgl_jatuh_tempo = '' THEN
        SET v_tgl_jatuh_tempo_calc = DATE_ADD(p_tgl_pinjam, INTERVAL p_durasi_pinjam DAY);
    ELSE
        SET v_tgl_jatuh_tempo_calc = p_tgl_jatuh_tempo;
    END IF;
    
    START TRANSACTION;
    
    -- Cek stok buku
    SELECT stok INTO v_stok FROM buku WHERE id_buku = p_id_buku FOR UPDATE;
    
    IF v_stok <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stok buku tidak mencukupi';
    END IF;
    
    -- Cek jumlah peminjaman aktif anggota
    SELECT COUNT(*) INTO v_jumlah_pinjam
    FROM peminjaman
    WHERE id_anggota = p_id_anggota AND status = 'dipinjam';
    
    IF v_jumlah_pinjam >= v_max_peminjaman THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Maksimal peminjaman aktif telah tercapai';
    END IF;
    
    -- Cek apakah anggota sudah meminjam buku yang sama dan belum dikembalikan
    SELECT COUNT(*) INTO v_duplikat
    FROM peminjaman
    WHERE id_anggota = p_id_anggota
      AND id_buku = p_id_buku
      AND status = 'dipinjam';
    
    IF v_duplikat > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Anda masih meminjam buku yang sama dan belum dikembalikan';
    END IF;
    
    -- Tambah peminjaman dengan tanggal jatuh tempo
    INSERT INTO peminjaman (id_anggota, id_buku, tgl_pinjam, tgl_jatuh_tempo, durasi_pinjam, status) 
    VALUES (
        p_id_anggota, 
        p_id_buku, 
        p_tgl_pinjam, 
        v_tgl_jatuh_tempo_calc,
        p_durasi_pinjam,
        'dipinjam'
    );
    
    -- Catatan: stok buku akan dikurangi oleh trigger trigger_kurangi_stok
    
    COMMIT;
END //
DELIMITER ;

-- 3. Stored Procedure untuk tambah pengembalian (dengan denda Rp. 20.000 per hari)
DELIMITER //
CREATE PROCEDURE tambah_pengembalian(
    IN p_id_pinjam INT,
    IN p_tgl_kembali DATE
)
BEGIN
    DECLARE v_id_buku INT;
    DECLARE v_tgl_jatuh_tempo DATE;
    DECLARE v_denda_per_hari DECIMAL(10,2);
    DECLARE v_hari_telat INT;
    DECLARE v_jumlah_denda DECIMAL(10,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Ambil id_buku dan tanggal jatuh tempo dari peminjaman
    SELECT id_buku, tgl_jatuh_tempo INTO v_id_buku, v_tgl_jatuh_tempo 
    FROM peminjaman 
    WHERE id_pinjam = p_id_pinjam
    FOR UPDATE;
    
    -- Tambah pengembalian
    INSERT INTO pengembalian (id_pinjam, tgl_kembali) 
    VALUES (p_id_pinjam, p_tgl_kembali);
    
    -- Update status peminjaman
    UPDATE peminjaman 
    SET status = 'dikembalikan'
    WHERE id_pinjam = p_id_pinjam;
    
    -- Catatan: stok buku akan ditambah oleh trigger trigger_tambah_stok
    
    -- Hitung denda jika terlambat
    SET v_hari_telat = 0;
    IF v_tgl_jatuh_tempo IS NOT NULL AND p_tgl_kembali > v_tgl_jatuh_tempo THEN
        SET v_hari_telat = DATEDIFF(p_tgl_kembali, v_tgl_jatuh_tempo);
    END IF;
    
    IF v_hari_telat > 0 THEN
        -- Ambil nilai denda per hari dari pengaturan, default 20000 jika tidak ada
        SELECT CAST(nilai AS DECIMAL(10,2)) INTO v_denda_per_hari
        FROM pengaturan
        WHERE nama_setting = 'denda_per_hari'
        LIMIT 1;
        
        IF v_denda_per_hari IS NULL OR v_denda_per_hari <= 0 THEN
            SET v_denda_per_hari = 20000;  -- Rp. 20.000 per hari
        END IF;
        
        SET v_jumlah_denda = v_denda_per_hari * v_hari_telat;
        
        INSERT INTO denda (id_pinjam, jumlah_denda, status, keterangan)
        VALUES (
            p_id_pinjam,
            v_jumlah_denda,
            'belum_lunas',
            CONCAT('Terlambat ', v_hari_telat, ' hari')
        );
    END IF;
    
    COMMIT;
END //
DELIMITER ;

-- 4. Update pengaturan denda per hari menjadi Rp. 20.000
INSERT INTO pengaturan (nama_setting, nilai, keterangan) 
VALUES ('denda_per_hari', '20000', 'Denda per hari keterlambatan (Rp)')
ON DUPLICATE KEY UPDATE nilai = '20000', keterangan = 'Denda per hari keterlambatan (Rp)';
