# Analisis Alur Aplikasi Perpustakaan

## 📋 Ringkasan Analisis

Setelah menganalisis struktur database dan alur aplikasi, ditemukan beberapa **ketidaksesuaian** dengan skema peminjaman dan pengembalian buku di perpustakaan kampus umumnya.

---

## ❌ Masalah yang Ditemukan

### 1. **Tidak Ada Batas Waktu Peminjaman (Due Date)**
**Masalah:**
- Tabel `peminjaman` hanya memiliki `tgl_pinjam`, tidak ada `tgl_jatuh_tempo` atau `batas_waktu`
- Tidak ada informasi kapan buku harus dikembalikan
- Tidak ada peringatan jika mendekati batas waktu

**Dampak:**
- User tidak tahu kapan harus mengembalikan buku
- Admin tidak bisa memantau peminjaman yang akan jatuh tempo
- Tidak ada kontrol waktu peminjaman

**Solusi yang Direkomendasikan:**
```sql
ALTER TABLE peminjaman ADD COLUMN tgl_jatuh_tempo DATE AFTER tgl_pinjam;
ALTER TABLE peminjaman ADD COLUMN durasi_pinjam INT DEFAULT 7 COMMENT 'Durasi dalam hari';
```

---

### 2. **Tidak Ada Sistem Denda**
**Masalah:**
- Tidak ada perhitungan denda jika terlambat mengembalikan buku
- Tidak ada tabel untuk menyimpan data denda
- Tidak ada notifikasi untuk peminjam yang terlambat

**Dampak:**
- Tidak ada insentif untuk mengembalikan buku tepat waktu
- Tidak ada pemasukan dari denda (jika diterapkan)
- Tidak ada tracking peminjam yang sering terlambat

**Solusi yang Direkomendasikan:**
```sql
CREATE TABLE denda (
    id_denda INT AUTO_INCREMENT PRIMARY KEY,
    id_pinjam INT NOT NULL,
    jumlah_denda DECIMAL(10,2) DEFAULT 0,
    status ENUM('belum_lunas', 'lunas') DEFAULT 'belum_lunas',
    tgl_bayar DATE NULL,
    keterangan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pinjam) REFERENCES peminjaman(id_pinjam) ON DELETE CASCADE
);
```

---

### 3. **Tidak Ada Batas Maksimal Peminjaman**
**Masalah:**
- Tidak ada pembatasan berapa banyak buku yang bisa dipinjam sekaligus oleh satu anggota
- Tidak ada validasi sebelum peminjaman baru
- Satu anggota bisa meminjam semua buku yang tersedia

**Dampak:**
- Buku bisa terkonsentrasi pada beberapa peminjam saja
- Tidak adil untuk anggota lain
- Tidak ada kontrol distribusi buku

**Solusi yang Direkomendasikan:**
- Tambahkan validasi di stored procedure `tambah_peminjaman`:
```sql
-- Cek jumlah peminjaman aktif anggota
SELECT COUNT(*) INTO v_jumlah_pinjam 
FROM peminjaman 
WHERE id_anggota = p_id_anggota AND status = 'dipinjam';

IF v_jumlah_pinjam >= 3 THEN -- Maksimal 3 buku
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Maksimal peminjaman adalah 3 buku';
END IF;
```

---

### 4. **User Hanya Bisa Print Surat, Tidak Terintegrasi dengan Sistem**
**Masalah:**
- User di `pinjam_buku.php` hanya bisa print surat pengajuan
- Tidak ada integrasi langsung ke sistem peminjaman
- Admin harus input manual peminjaman dari surat yang dicetak

**Dampak:**
- Proses tidak efisien
- User tidak bisa langsung request peminjaman secara digital
- Potensi kesalahan input manual oleh admin

**Solusi yang Direkomendasikan:**
- Tambahkan status peminjaman: `pending`, `disetujui`, `ditolak`, `dipinjam`, `dikembalikan`
- User bisa submit request peminjaman langsung dari sistem
- Admin bisa approve/reject request

---

### 5. **Tidak Ada Validasi Duplikasi Peminjaman**
**Masalah:**
- Tidak ada validasi apakah anggota sudah meminjam buku yang sama sebelumnya
- Tidak ada validasi apakah anggota masih memiliki buku yang belum dikembalikan

**Dampak:**
- Satu anggota bisa meminjam buku yang sama berkali-kali
- Tidak ada kontrol terhadap peminjam yang belum mengembalikan buku lama

**Solusi yang Direkomendasikan:**
```sql
-- Di stored procedure tambah_peminjaman, tambahkan:
-- Cek apakah anggota sudah meminjam buku yang sama dan belum dikembalikan
SELECT COUNT(*) INTO v_duplikat
FROM peminjaman
WHERE id_anggota = p_id_anggota 
  AND id_buku = p_id_buku 
  AND status = 'dipinjam';

IF v_duplikat > 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Anda masih memiliki buku yang sama yang belum dikembalikan';
END IF;
```

---

### 6. **Tidak Ada Fitur Perpanjangan Peminjaman**
**Masalah:**
- Tidak ada opsi untuk memperpanjang waktu peminjaman
- User harus mengembalikan dan meminjam ulang jika ingin lebih lama

**Dampak:**
- Tidak fleksibel untuk user yang butuh waktu lebih lama
- Proses tidak efisien

**Solusi yang Direkomendasikan:**
```sql
ALTER TABLE peminjaman ADD COLUMN perpanjangan INT DEFAULT 0 COMMENT 'Jumlah perpanjangan';
ALTER TABLE peminjaman ADD COLUMN tgl_perpanjangan DATE NULL;
```

---

### 7. **Tidak Ada Notifikasi dan Reminder**
**Masalah:**
- Tidak ada notifikasi untuk peminjaman yang akan jatuh tempo
- Tidak ada reminder untuk peminjam yang terlambat
- Tidak ada dashboard untuk melihat peminjaman yang perlu perhatian

**Dampak:**
- Buku bisa terlambat dikembalikan tanpa peringatan
- Admin harus manual cek peminjaman yang akan jatuh tempo

**Solusi yang Direkomendasikan:**
- Tambahkan query untuk menampilkan peminjaman yang akan jatuh tempo dalam 3 hari
- Tambahkan badge/alert untuk peminjaman yang terlambat
- Tambahkan email notification (opsional)

---

## ✅ Yang Sudah Baik

1. ✅ **Stok buku otomatis berkurang/bertambah** - Sudah menggunakan stored procedure dan trigger
2. ✅ **Status peminjaman** - Sudah ada status `dipinjam` dan `dikembalikan`
3. ✅ **Riwayat peminjaman** - Sudah ada tracking riwayat
4. ✅ **Validasi stok** - Sudah ada validasi stok sebelum peminjaman
5. ✅ **Transaction handling** - Sudah menggunakan transaction di stored procedure

---

## 🔧 Rekomendasi Perbaikan Prioritas

### **Prioritas Tinggi (Harus Diperbaiki)**

1. **Tambahkan Batas Waktu Peminjaman**
   - Tambah kolom `tgl_jatuh_tempo` dan `durasi_pinjam`
   - Update stored procedure untuk auto-set due date
   - Tampilkan due date di semua halaman peminjaman

2. **Tambahkan Validasi Batas Maksimal Peminjaman**
   - Validasi maksimal 3 buku per anggota
   - Tampilkan jumlah buku yang sedang dipinjam di dashboard user

3. **Integrasikan Request Peminjaman User ke Sistem**
   - Ubah `pinjam_buku.php` agar langsung submit ke database dengan status `pending`
   - Admin bisa approve/reject dari halaman peminjaman

### **Prioritas Sedang (Sangat Direkomendasikan)**

4. **Tambahkan Sistem Denda**
   - Buat tabel `denda`
   - Hitung denda otomatis saat pengembalian terlambat
   - Tampilkan denda di riwayat dan dashboard

5. **Tambahkan Validasi Duplikasi**
   - Cegah peminjaman buku yang sama jika masih dipinjam
   - Validasi sebelum approve peminjaman baru

### **Prioritas Rendah (Nice to Have)**

6. **Fitur Perpanjangan Peminjaman**
   - Tambah opsi perpanjangan di dashboard user
   - Maksimal 1x perpanjangan per peminjaman

7. **Notifikasi dan Reminder**
   - Dashboard alert untuk peminjaman yang akan jatuh tempo
   - Badge untuk peminjaman terlambat

---

## 📝 Struktur Database yang Direkomendasikan

```sql
-- Update tabel peminjaman
ALTER TABLE peminjaman 
ADD COLUMN tgl_jatuh_tempo DATE AFTER tgl_pinjam,
ADD COLUMN durasi_pinjam INT DEFAULT 7 COMMENT 'Durasi dalam hari' AFTER tgl_jatuh_tempo,
ADD COLUMN perpanjangan INT DEFAULT 0 COMMENT 'Jumlah perpanjangan',
ADD COLUMN tgl_perpanjangan DATE NULL,
MODIFY COLUMN status ENUM('pending', 'disetujui', 'ditolak', 'dipinjam', 'dikembalikan') DEFAULT 'pending';

-- Tabel denda
CREATE TABLE denda (
    id_denda INT AUTO_INCREMENT PRIMARY KEY,
    id_pinjam INT NOT NULL,
    jumlah_denda DECIMAL(10,2) DEFAULT 0,
    status ENUM('belum_lunas', 'lunas') DEFAULT 'belum_lunas',
    tgl_bayar DATE NULL,
    keterangan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pinjam) REFERENCES peminjaman(id_pinjam) ON DELETE CASCADE
);

-- Tabel pengaturan (untuk konfigurasi sistem)
CREATE TABLE pengaturan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_setting VARCHAR(100) UNIQUE NOT NULL,
    nilai VARCHAR(255) NOT NULL,
    keterangan TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default settings
INSERT INTO pengaturan (nama_setting, nilai, keterangan) VALUES
('maksimal_peminjaman', '3', 'Maksimal jumlah buku yang bisa dipinjam sekaligus'),
('durasi_peminjaman', '7', 'Durasi peminjaman dalam hari'),
('denda_per_hari', '2000', 'Denda per hari keterlambatan (rupiah)'),
('maksimal_perpanjangan', '1', 'Maksimal jumlah perpanjangan');
```

---

## 🎯 Kesimpulan

Aplikasi saat ini sudah memiliki **fondasi yang baik** dengan stored procedure dan trigger untuk manajemen stok. Namun, masih **kurang beberapa fitur penting** yang standar di perpustakaan kampus:

1. ❌ Batas waktu peminjaman
2. ❌ Sistem denda
3. ❌ Batas maksimal peminjaman
4. ❌ Integrasi request user ke sistem
5. ❌ Validasi duplikasi

**Rekomendasi:** Mulai perbaiki dari **Prioritas Tinggi** terlebih dahulu, karena ini adalah fitur fundamental yang harus ada di sistem perpustakaan kampus.
